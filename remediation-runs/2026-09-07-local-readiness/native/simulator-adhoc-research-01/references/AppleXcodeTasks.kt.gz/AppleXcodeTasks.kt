/*
 * Copyright 2010-2021 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.gradle.plugin.mpp.apple

import org.gradle.api.DefaultTask
import org.gradle.api.Project
import org.gradle.api.Task
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.plugins.BasePlugin
import org.gradle.api.provider.Provider
import org.gradle.api.tasks.*
import org.gradle.internal.extensions.core.serviceOf
import org.gradle.process.ExecOperations
import org.gradle.work.DisableCachingByDefault
import org.jetbrains.kotlin.gradle.dsl.KotlinNativeBinaryContainer
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.Companion.kotlinPropertiesProvider
import org.jetbrains.kotlin.gradle.plugin.diagnostics.KotlinToolingDiagnostics
import org.jetbrains.kotlin.gradle.plugin.diagnostics.reportDiagnostic
import org.jetbrains.kotlin.gradle.plugin.mpp.*
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.FrameworkCopy.Companion.dsymFile
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.swiftexport.SwiftExportDSLConstants
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.swiftexport.SwiftExportExtension
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.swiftexport.registerSwiftExportTask
import org.jetbrains.kotlin.gradle.tasks.FatFrameworkTask
import org.jetbrains.kotlin.gradle.tasks.dependsOn
import org.jetbrains.kotlin.gradle.tasks.locateOrRegisterTask
import org.jetbrains.kotlin.gradle.tasks.registerTask
import org.jetbrains.kotlin.gradle.utils.getFile
import org.jetbrains.kotlin.gradle.utils.lowerCamelCaseName
import org.jetbrains.kotlin.gradle.utils.mapToFile
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.swiftimport.*
import org.jetbrains.kotlin.gradle.plugin.mpp.apple.swiftimport.GenerateSyntheticLinkageImportProject.Companion.SYNTHETIC_IMPORT_TARGET_MAGIC_NAME
import java.io.File
import java.nio.file.Paths
import javax.inject.Inject
import kotlin.collections.component1
import kotlin.collections.component2

@Suppress("ConstPropertyName")
internal object AppleXcodeTasks {
    const val embedAndSignTaskPrefix = "embedAndSign"
    const val embedAndSignTaskPostfix = "AppleFrameworkForXcode"
    const val validateArchitecturesForTaskPrefix = "validateArchitecturesFor"
    const val checkSandboxAndWriteProtection = "checkSandboxAndWriteProtection"
}

private class AssembleFramework(
    val taskProvider: TaskProvider<out Task>,
    val frameworkPath: Provider<File>?,
    val dsymPath: Provider<File>?,
)

private fun Project.registerAssembleAppleFrameworkTask(framework: Framework, environment: XcodeEnvironment): AssembleFramework? {
    if (!framework.konanTarget.family.isAppleFamily || !framework.konanTarget.enabledOnCurrentHostForBinariesCompilation) return null

    val envTargets = environment.targets
    val needFatFramework = envTargets.size > 1
    val envBuildType = environment.buildType

    val frameworkBuildType = framework.buildType
    val frameworkTarget = framework.target
    val isRequestedFramework = envTargets.contains(frameworkTarget.konanTarget)

    val frameworkTaskName = lowerCamelCaseName(
        "assemble",
        framework.namePrefix,
        frameworkBuildType.getName(),
        "AppleFrameworkForXcode",
        if (isRequestedFramework && needFatFramework) null else frameworkTarget.name //for fat framework we need common name
    )

    if (!shouldRegisterEmbedTask(environment, frameworkTaskName)) {
        return null
    }

    if (!isRequestedFramework) {
        return AssembleFramework(
            locateOrRegisterTask<DefaultTask>(frameworkTaskName) { task ->
                task.description = "Packs $frameworkBuildType ${frameworkTarget.name} framework for Xcode"
                task.isEnabled = false
            },
            null,
            null,
        )
    }

    val frameworkPath: Provider<File>
    val dsymPath: Provider<File>

    val assembleFrameworkTask = when {
        needFatFramework -> locateOrRegisterTask<FatFrameworkTask>(frameworkTaskName) { task ->
            task.description = "Packs $frameworkBuildType fat framework for Xcode"
            task.baseName = framework.baseName
            task.destinationDirProperty.fileProvider(appleFrameworkDir(frameworkTaskName, environment))
            task.isEnabled = frameworkBuildType == envBuildType
        }.also { taskProvider ->
            taskProvider.configure { task -> task.from(framework) }
            frameworkPath = taskProvider.map { it.fatFramework }
            dsymPath = taskProvider.map { it.frameworkLayout.dSYM.rootDir }
        }
        else -> registerTask<FrameworkCopy>(frameworkTaskName) { task ->
            task.description = "Packs $frameworkBuildType ${frameworkTarget.name} framework for Xcode"
            task.isEnabled = frameworkBuildType == envBuildType
            task.sourceFramework.fileProvider(framework.linkTaskProvider.map { it.outputFile.get() })
            task.sourceDsym.fileProvider(dsymFile(task.sourceFramework.mapToFile()))
            task.destinationDirectory.fileProvider(appleFrameworkDir(frameworkTaskName, environment))
        }.also { taskProvider ->
            frameworkPath = taskProvider.map { it.destinationFramework }
            dsymPath = taskProvider.map { it.destinationDsym }
        }
    }

    return AssembleFramework(
        assembleFrameworkTask,
        frameworkPath,
        dsymPath,
    )
}

private fun Project.registerSymbolicLinkTask(
    frameworkCopyTaskName: String,
    builtProductsDir: Provider<File>,
): TaskProvider<SymbolicLinkToFrameworkTask> {
    return locateOrRegisterTask<SymbolicLinkToFrameworkTask>(
        lowerCamelCaseName(
            "symbolicLinkTo",
            frameworkCopyTaskName
        )
    ) {
        it.enabled = kotlinPropertiesProvider.appleCreateSymbolicLinkToFrameworkInBuiltProductsDir
        it.builtProductsDirectory.set(builtProductsDir)
    }
}

private fun Project.registerCreateBuildSystemDirectory(
    builtProductsDir: Provider<File>,
): TaskProvider<*> {
    return locateOrRegisterTask<CreateBuildSystemDirectory>("createBuildSystemDirectory") {
        it.buildSystemDirectory.set(builtProductsDir)
    }
}

private fun Project.registerDsymArchiveTask(
    frameworkCopyTaskName: String,
    dsymPath: Provider<File>?,
    dwarfDsymFolderPath: String?,
    action: XcodeEnvironment.Action?,
    isStatic: Provider<Boolean>,
): TaskProvider<*> {
    return locateOrRegisterTask<CopyDsymDuringArchiving>(
        lowerCamelCaseName(
            "copyDsymFor",
            frameworkCopyTaskName
        )
    ) { task ->
        task.onlyIf { action == XcodeEnvironment.Action.install && !isStatic.get() }
        dwarfDsymFolderPath?.let { task.dwarfDsymFolderPath.set(it) }
        dsymPath?.let { task.dsymPath.set(it) }
    }
}

private fun fireEnvException(frameworkTaskName: String, environment: XcodeEnvironment): Nothing =
    fireEnvException(frameworkTaskName, environment.buildType, environment.toString())

private fun fireEnvException(frameworkTaskName: String, envBuildType: NativeBuildType?, environment: String): Nothing {
    val envConfiguration = System.getenv("CONFIGURATION")
    if (envConfiguration != null && envBuildType == null) {
        throw IllegalStateException(
            "Unable to detect Kotlin framework build type for CONFIGURATION=$envConfiguration automatically. " +
                    "Specify 'KOTLIN_FRAMEWORK_BUILD_TYPE' to 'debug' or 'release'" +
                    "\n$environment"
        )
    } else {
        throw IllegalStateException(
            "Please run the $frameworkTaskName task from Xcode " +
                    "('SDK_NAME', 'CONFIGURATION', 'TARGET_BUILD_DIR', 'ARCHS' and 'FRAMEWORKS_FOLDER_PATH' not provided)" +
                    "\n$environment"
        )
    }
}

// FIXME: KT-84852 We also need the SwiftPM import linkage check here
private fun isRequestedBinary(binary: NativeBinary, environment: XcodeEnvironment) =
    binary.buildType == environment.buildType && environment.targets.contains(binary.konanTarget)

internal fun Project.registerEmbedSwiftExportTask(
    target: KotlinNativeTarget,
    environment: XcodeEnvironment,
    swiftExportExtension: SwiftExportExtension,
) {
    val envTargets = environment.targets
    val binaryTaskName = embedSwiftExportTaskName()

    if (!isRunWithXcodeEnvironment(
            environment,
            binaryTaskName,
            "Embed swift export library as requested by Xcode's environment variables"
        )
    ) {
        return
    }

    val envBuildType = environment.buildType
        ?: error("Missing required environment variable: CONFIGURATION. Please verify that the CONFIGURATION variable is correctly set in your Xcode's environment settings")

    val validateTask = registerValidateXcodeArchitecturesTask(
        frameworkTaskName = binaryTaskName,
        environment = environment,
        frameworkName = SwiftExportDSLConstants.SWIFT_EXPORT_EXTENSION_NAME,
        configuredTarget = target.konanTarget.visibleName,
    )

    val embedAndSignTask = locateOrRegisterTask<EmbedSwiftExportForXcodeTask>(binaryTaskName) { task ->
        task.group = BasePlugin.BUILD_GROUP
        task.description = "Embed Swift Export artifacts requested by Xcode's environment variables"
        task.inputs.apply {
            property("type", envBuildType)
            property("targets", envTargets)
        }
    }

    embedAndSignTask.dependsOn(validateTask)

    if (!envTargets.contains(target.konanTarget)) {
        return
    }

    val sandBoxTask = checkSandboxAndWriteProtectionTask(environment, environment.userScriptSandboxingEnabled)

    val swiftExportTask = registerSwiftExportTask(
        swiftExportExtension,
        SwiftExportDSLConstants.TASK_GROUP,
        envBuildType,
        target
    )

    swiftExportTask.dependsOn(sandBoxTask)
    embedAndSignTask.dependsOn(swiftExportTask)
}

internal fun Project.registerEmbedAndSignAppleFrameworkTask(framework: Framework, environment: XcodeEnvironment) {
    val frameworkTaskName = framework.embedAndSignTaskName()

    if (!isRunWithXcodeEnvironment(
            environment,
            frameworkTaskName,
            "Embed and sign ${framework.namePrefix} framework as requested by Xcode's environment variables"
        )
    ) {
        return
    }

    val validateTask = registerValidateXcodeArchitecturesTask(
        frameworkTaskName = frameworkTaskName,
        environment = environment,
        frameworkName = framework.baseName,
        configuredTarget = framework.konanTarget.visibleName,
    )
    val sandBoxTask = checkSandboxAndWriteProtectionTask(environment, environment.userScriptSandboxingEnabled)
    val assembleTask = registerAssembleAppleFrameworkTask(framework, environment) ?: return
    val matchesRequestedBinary = isRequestedBinary(framework, environment)

    val builtProductsDir = builtProductsDir(frameworkTaskName, environment)
    val createBuildSystemDirectory = registerCreateBuildSystemDirectory(builtProductsDir)

    val symbolicLinkTask = registerSymbolicLinkTask(
        frameworkCopyTaskName = assembleTask.taskProvider.name,
        builtProductsDir = builtProductsDir
    )
    symbolicLinkTask.dependsOn(createBuildSystemDirectory)
    symbolicLinkTask.configure { task ->
        task.onlyIf("Binary ${framework.name} does not match Xcode-requested build type or architecture") { matchesRequestedBinary }
        assembleTask.frameworkPath?.let { task.frameworkPath.set(it) }
        assembleTask.dsymPath?.let { task.dsymPath.set(it) }
        task.shouldDsymLinkExist.set(
            when (environment.action) {
                // Don't create symbolic link for dSYM when archiving: KT-71423
                XcodeEnvironment.Action.install -> false
                XcodeEnvironment.Action.other,
                null -> !framework.isStatic
            }
        )
    }

    assembleTask.taskProvider.dependsOn(sandBoxTask)
    framework.linkTaskProvider.dependsOn(sandBoxTask)

    if (!project.kotlinPropertiesProvider.disableSwiftPMImport) {
        val xcodeProjectPathForKmpIJPlugin = locateOrRegisterSwiftPMDependenciesExtension().xcodeProjectPathForKmpIJPlugin
        val envProjectPath = project.providers.environmentVariable(PROJECT_FILE_PATH_ENV)
        val projectPath = callingProjectPathProvider()
        val regenerateSyntheticLinkageProject = locateOrRegisterRegenerateLinkageImportProjectTask()
        regenerateSyntheticLinkageProject.configure {
            it.doFirst {
                if (!envProjectPath.isPresent && !xcodeProjectPathForKmpIJPlugin.isPresent) {
                    error("Please make sure $PROJECT_FILE_PATH_ENV environment variable is present")
                }
            }
            it.syntheticImportProjectRoot.set(
                projectPath.flatMap {
                    project.layout.dir(
                        project.provider { File(it).parentFile.resolve(SYNTHETIC_IMPORT_TARGET_MAGIC_NAME) }
                    )
                }
            )
        }

        val syntheticLinkageImportProjectCheck = checkSyntheticImportProjectIsCorrectlyIntegrated()
        regenerateSyntheticLinkageProject.dependsOn(syntheticLinkageImportProjectCheck)
        assembleTask.taskProvider.dependsOn(regenerateSyntheticLinkageProject)
        framework.linkTaskProvider.dependsOn(regenerateSyntheticLinkageProject)
    }

    val embedAndSignTask = registerEmbedTask(
        framework,
        frameworkTaskName,
        environment,
    ) { !framework.isStatic } ?: return
    embedAndSignTask.dependsOn(validateTask)
    if (matchesRequestedBinary) {
        embedAndSignTask.dependsOn(assembleTask.taskProvider)
        embedAndSignTask.dependsOn(symbolicLinkTask)
    }

    if (kotlinPropertiesProvider.appleCopyDsymDuringArchiving && matchesRequestedBinary) {
        val dsymCopyTask = registerDsymArchiveTask(
            frameworkCopyTaskName = frameworkTaskName,
            dsymPath = assembleTask.dsymPath,
            dwarfDsymFolderPath = environment.dwarfDsymFolderPath,
            action = environment.action,
            isStatic = provider { framework.isStatic },
        )
        // FIXME: KT-71720
        // Dsym copy task must execute after symbolic link task because symbolic link task does clean up for KT-68257 and dSYM is copied to the same location
        dsymCopyTask.dependsOn(symbolicLinkTask)
        dsymCopyTask.dependsOn(assembleTask.taskProvider)
        embedAndSignTask.dependsOn(dsymCopyTask)
    }
}

private fun Project.isRunWithXcodeEnvironment(
    environment: XcodeEnvironment,
    taskName: String,
    taskDescription: String,
): Boolean {
    val envBuildType = environment.buildType
    val envTargets = environment.targets
    val envRepresentation = environment.toString()
    val envEmbeddedFrameworksDir = environment.embeddedFrameworksDir

    if (envBuildType == null || envTargets.isEmpty() || envEmbeddedFrameworksDir == null) {
        locateOrRegisterTask<DefaultTask>(taskName) { task ->
            task.group = BasePlugin.BUILD_GROUP
            task.description = taskDescription
            task.doFirst {
                fireEnvException(taskName, envBuildType, envRepresentation)
            }
        }

        return false
    }

    return true
}

private fun Project.registerEmbedTask(
    binary: NativeBinary,
    frameworkTaskName: String,
    environment: XcodeEnvironment,
    embedAndSignEnabled: () -> Boolean = { true },
): TaskProvider<EmbedAndSignTask>? {
    val envBuildType = environment.buildType
    val envTargets = environment.targets
    val envEmbeddedFrameworksDir = environment.embeddedFrameworksDir
    val envSign = environment.sign
    val userScriptSandboxingEnabled = environment.userScriptSandboxingEnabled

    if (envBuildType == null || envTargets.isEmpty() || envEmbeddedFrameworksDir == null) return null

    val embedAndSignTask = locateOrRegisterTask<EmbedAndSignTask>(frameworkTaskName) { task ->
        task.group = BasePlugin.BUILD_GROUP
        task.description = "Embed and sign ${binary.namePrefix} framework as requested by Xcode's environment variables"
        task.isEnabled = embedAndSignEnabled()
        task.onlyIf("No framework binary matches Xcode-requested build type and architectures") {
            task.sourceFramework.isPresent
        }
        task.inputs.apply {
            property("type", envBuildType)
            property("targets", envTargets)
            property("embeddedFrameworksDir", envEmbeddedFrameworksDir)
            property("userScriptSandboxingEnabled", userScriptSandboxingEnabled)
            if (envSign != null) {
                property("sign", envSign)
            }
        }
    }

    if (isRequestedBinary(binary, environment)) {
        embedAndSignTask.configure { task ->
            val frameworkFile = binary.outputFile
            task.sourceFramework.fileProvider(appleFrameworkDir(frameworkTaskName, environment).map { it.resolve(frameworkFile.name) })
            task.destinationDirectory.set(envEmbeddedFrameworksDir)
            if (envSign != null) {
                task.doLast {
                    val binaryToSign = envEmbeddedFrameworksDir
                        .resolve(frameworkFile.name)
                        .resolve(frameworkFile.nameWithoutExtension)
                    task.execOperations.exec {
                        it.commandLine("codesign", "--force", "--sign", envSign, "--", binaryToSign)
                    }
                }
            }
        }
    }

    return embedAndSignTask
}

internal fun checkIfTheLinkageProjectIsConnectedToTheXcodeProject(
    execOperations: ExecOperations,
    gradleProjectPath: String,
    xcodeProjectThatCalledEmbedAndSign: File,
    rootProjectDir: File,
) {
    val xcodeProject = deserializeXcodeProject(xcodeProjectThatCalledEmbedAndSign.resolve("project.pbxproj"), execOperations)
    val linkageProducts = linkageProductsReferencedInPBXObjects(xcodeProject)
    val hasSyntheticImportProjectReference = linkageProducts.isNotEmpty()
    if (!hasSyntheticImportProjectReference) {
        val taskCall = if (gradleProjectPath == ":") {
            ":${IntegrateLinkagePackageIntoXcodeProject.TASK_NAME}"
        } else "${gradleProjectPath}:${IntegrateLinkagePackageIntoXcodeProject.TASK_NAME}"

        val gradleCommand = searchForGradlew(xcodeProjectThatCalledEmbedAndSign)?.path
            ?: rootProjectDir.resolve("gradlew").takeIf { it.exists() }?.path
            ?: "gradle"
        val messageLines = listOf(
            "You have SwiftPM dependencies with embedAndSign integration.",
            "Please integrate with synthetic import linkage project by",
            "running the following command:",
            "${PROJECT_PATH_ENV}='${xcodeProjectThatCalledEmbedAndSign.path}' '${gradleCommand}' -p '${rootProjectDir}' '${taskCall}' -i"
        )
        messageLines.forEach {
            println("error: $it")
        }
        error(messageLines.joinToString("\n"))
    }
}

private fun Project.registerValidateXcodeArchitecturesTask(
    frameworkTaskName: String,
    environment: XcodeEnvironment,
    frameworkName: String,
    configuredTarget: String,
): TaskProvider<ValidateXcodeArchitecturesTask> {
    val taskName = lowerCamelCaseName(AppleXcodeTasks.validateArchitecturesForTaskPrefix, frameworkTaskName)

    val taskProvider = locateOrRegisterTask<ValidateXcodeArchitecturesTask>(taskName) { task ->
        task.description = "Check that Xcode-requested architectures are configured in Gradle"
        task.requestedTargets.set(environment.targets.map { it.visibleName })
        task.frameworkName.set(frameworkName)
    }

    taskProvider.configure { task ->
        task.configuredTargets.add(configuredTarget)
    }

    return taskProvider
}

private fun Project.checkSandboxAndWriteProtectionTask(
    environment: XcodeEnvironment,
    userScriptSandboxingEnabled: Boolean,
) =
    locateOrRegisterTask<CheckSandboxAndWriteProtectionTask>(AppleXcodeTasks.checkSandboxAndWriteProtection) { task ->
        task.group = BasePlugin.BUILD_GROUP
        task.description = "Check BUILT_PRODUCTS_DIR accessible and ENABLE_USER_SCRIPT_SANDBOXING not enabled"

        environment.builtProductsDir?.let { task.builtProductsDir.set(it) }
        task.userScriptSandboxingEnabled.set(userScriptSandboxingEnabled)
    }

private fun Project.checkSyntheticImportProjectIsCorrectlyIntegrated(): TaskProvider<*> {
    val hasDirectOrTransitiveSwiftPMDependencies = hasDirectOrTransitiveSwiftPMDependencies()

    val xcodeProjectPathForKmpIJPlugin = locateOrRegisterSwiftPMDependenciesExtension().xcodeProjectPathForKmpIJPlugin
    val envProjectPath = project.providers.environmentVariable(PROJECT_FILE_PATH_ENV)
    val projectPath = callingProjectPathProvider()

    return locateOrRegisterTask<DefaultTask>("checkSyntheticImportProjectIsCorrectlyIntegrated") { task ->
        task.group = BasePlugin.BUILD_GROUP
        task.description = "Check linkage project for embedAndSign is integrated correctly into the project"
        val execOps = project.serviceOf<ExecOperations>()
        val gradleProjectPath = project.path
        val rootProjectDir = rootProject.projectDir
        task.enabled = !kotlinPropertiesProvider.suppressXcodeIntegrationCheck
        task.dependsOn(hasDirectOrTransitiveSwiftPMDependencies)
        task.onlyIf { hasDirectOrTransitiveSwiftPMDependencies.get() }
        task.doFirst {
            if (!envProjectPath.isPresent && !xcodeProjectPathForKmpIJPlugin.isPresent) {
                error("Please make sure $PROJECT_FILE_PATH_ENV environment variable is present")
            }

            checkIfTheLinkageProjectIsConnectedToTheXcodeProject(
                execOps,
                gradleProjectPath,
                File(projectPath.get()),
                rootProjectDir,
            )
        }
    }
}

private fun Project.shouldRegisterEmbedTask(environment: XcodeEnvironment, frameworkTaskName: String): Boolean {
    val envBuildType = environment.buildType
    val envTargets = environment.targets

    if (envBuildType == null || envTargets.isEmpty() || environment.builtProductsDir == null) {
        val envConfiguration = System.getenv("CONFIGURATION")
        if (envTargets.isNotEmpty() && envConfiguration != null) {
            project.reportDiagnostic(KotlinToolingDiagnostics.UnknownAppleFrameworkBuildType(envConfiguration))
        } else {
            logger.debug("Not registering $frameworkTaskName, since not called from Xcode")
        }
        return false
    }

    return true
}

private fun NativeBinary.embedAndSignTaskName(): String = lowerCamelCaseName(
    AppleXcodeTasks.embedAndSignTaskPrefix,
    namePrefix,
    AppleXcodeTasks.embedAndSignTaskPostfix
)

private fun embedSwiftExportTaskName(): String = lowerCamelCaseName(
    "embed",
    SwiftExportDSLConstants.SWIFT_EXPORT_EXTENSION_NAME,
    "ForXcode"
)

private val NativeBinary.namePrefix: String
    get() = KotlinNativeBinaryContainer.extractPrefixFromBinaryName(
        name,
        buildType,
        outputKind.taskNameClassifier
    )

/**
 * [XcodeEnvironment.builtProductsDir] if not disabled.
 *
 * Or if [XcodeEnvironment.frameworkSearchDir] is absolute use it, otherwise make it relative to buildDir/xcode-frameworks
 */
private fun Project.appleFrameworkDir(frameworkTaskName: String, environment: XcodeEnvironment): Provider<File> {
    return layout.buildDirectory.dir("xcode-frameworks").map {
        it.asFile.resolve(environment.frameworkSearchDir ?: fireEnvException(frameworkTaskName, environment))
    }
}

private fun Project.builtProductsDir(frameworkTaskName: String, environment: XcodeEnvironment): Provider<File> {
    val builtProductsDir = environment.builtProductsDir
    val envBuildType = environment.buildType
    val envRepresentation = environment.toString()

    return project.provider {
        builtProductsDir ?: fireEnvException(frameworkTaskName, envBuildType, envRepresentation)
    }
}


/**
 * macOS frameworks contain symlinks which are resolved/removed by the Gradle [Copy] task.
 * To preserve these symlinks we are using the `cp` command instead.
 * See https://youtrack.jetbrains.com/issue/KT-48594.
 */
@DisableCachingByDefault(because = "Caching breaks symlinks inside frameworks")
internal abstract class FrameworkCopy : DefaultTask() {

    @get:Inject
    abstract val execOperations: ExecOperations

    @get:PathSensitive(PathSensitivity.ABSOLUTE)
    @get:InputDirectory
    abstract val sourceFramework: DirectoryProperty

    @get:PathSensitive(PathSensitivity.ABSOLUTE)
    @get:InputFiles
    @get:Optional
    @get:IgnoreEmptyDirectories
    abstract val sourceDsym: DirectoryProperty

    @get:OutputDirectory
    abstract val destinationDirectory: DirectoryProperty

    @get:Internal
    internal val destinationFramework get() = destinationDirectory.getFile().resolve(sourceFramework.getFile().name)

    @get:Internal
    internal val destinationDsym get() = destinationDirectory.getFile().resolve(sourceDsym.getFile().name)

    @TaskAction
    open fun copy() {
        copy(sourceFramework.getFile(), destinationFramework)
        if (sourceDsym.isPresent && sourceDsym.getFile().exists()) {
            copy(sourceDsym.getFile(), destinationDsym)
        }
    }

    private fun copy(
        source: File,
        destination: File,
    ) {
        if (destination.exists()) {
            execOperations.exec { it.commandLine("rm", "-r", destination.absolutePath) }
        }
        execOperations.exec { it.commandLine("cp", "-R", source.absolutePath, destination.absolutePath) }
    }

    companion object {
        fun dsymFile(framework: Provider<File>): Provider<File> = framework.map { File(it.path + ".dSYM") }
    }
}

@DisableCachingByDefault(because = "Lifecycle task, no outputs")
internal abstract class EmbedSwiftExportForXcodeTask : DefaultTask()

@DisableCachingByDefault(because = "Caching breaks symlinks inside frameworks")
internal abstract class EmbedAndSignTask : FrameworkCopy()

private fun Project.callingProjectPathProvider(): Provider<String> {
    val xcodeProjectPathForKmpIJPlugin = locateOrRegisterSwiftPMDependenciesExtension().xcodeProjectPathForKmpIJPlugin
    // Resolve PROJECT_FILE_PATH symlinks (xcodebuild input) to match Gradle's canonicalized project dir;
    // this avoids /var -> /private/var mismatches in relative path computation on macOS.
    // FIXME: Replace Provider<String> with Provider<File> to avoid string-based normalization (KT-84304).
    val envProjectPath = project.providers.environmentVariable(PROJECT_FILE_PATH_ENV).map { Paths.get(it).toRealPath().toString() }

    return envProjectPath.orElse(
        xcodeProjectPathForKmpIJPlugin.map {
            it.asFile.path
        }.orElse(
            // FIXME: KT-84215 This is a stub to unblock integration tests. We need to rework how integration tests that ran without an Xcode project will function
            project.layout.projectDirectory.asFile.path
        )
    )
}

private const val PROJECT_FILE_PATH_ENV = "PROJECT_FILE_PATH"
